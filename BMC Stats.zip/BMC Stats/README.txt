Program:	BMC stats for league of legends
Author:		Bmckalip
Version:	0.1

INSTRUCTIONS: 
1. extract the ENTIRE archive (including the initially empty "Game Stats" folder) anywhere on your computer.
2. start a game of League of Legends along with the "BMC stats" exe file.
3. Follow the on screen instructions to reset and start the counter once you finish loading into game
4. When the game ends follow the on screen instructions to reset the counter.
-------------------------------------------------------------------------------------------------------------------
Note: closing the program will stop the recording of stats, minimizing is fine.
Note: closing the program before resetting the counter will NOT save the last recording to file. 
Note: The "Game Stats" folder is REQUIRED. Do not modify its name, or game stats will not be saved to file.
Note: A settings file will be released in the future allowing for various customizability
-------------------------------------------------------------------------------------------------------------------

Thanks for using the alpha version of BMC stats! Look forward to future updates and releases!